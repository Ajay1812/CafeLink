import { Component } from "react";
import axios from "axios";
import Update_offer from "./Update_offer";
import Add_offer_admin from "./Add_offer_admin.js";
import './Display_offer_cafe.css'
// import { PanoramaRounded } from "@material-ui/icons";
// import { response } from "express";
// import Table from '@material-ui/core/Table';
// import TableBody from '@material-ui/core/TableBody';
// import TableCell from '@material-ui/core/TableCell';
// import TableContainer from '@material-ui/core/TableContainer';
// import TableHead from '@material-ui/core/TableHead';
// import TableRow from '@material-ui/core/TableRow';
// import Paper from '@material-ui/core/Paper';

class Display extends Component {
    constructor() {
        super();
        this.state = {
            st: false,
            io: false,
            ca: "",
            qw: "",
            er: "",
            message: "",
            kalu: [],
        };
    }

    componentDidMount() {
        axios
            .get("http://localhost/Offer_display.php")
            .then((response) => {
                this.setState({ kalu: response.data });
                console.log(response.data);
            })
            .catch((err) => {
                console.log("failed");
            });
    }

    update = (e, g, f) => {
        this.setState({ st: true });
        console.log(e);
        console.log(g);
        this.setState({ ca: e });
        this.setState({ qw: g });
        this.setState({ er: f });
    };

    Del = (e, g) => {
        console.log(e + " Delete");
        console.log(g + " Delete");
        const Cafe_id = e;
        const offer_name = g;
        const data = { Cafe_id, offer_name };
        
        axios.get("http://localhost/Offer_delete.php", { params: data })
            .then((qwerty) => {
                this.setState({ message: qwerty.data.response });
            })
            .catch((err) => {
                console.log("failed");
            });
    };
    

    Insert = () => {
        this.setState({ io: true });
        
    };

    render() {
        return (
            <div>
                {this.state.st ? (
                    <Update_offer t1={this.state.ca} t2={this.state.qw} />
                ) : this.state.io ? (
                    <Add_offer_admin />
                ) : (<div>
                    <h2 className = "head">Display Offers</h2> <br/>

                    <div className = "dis" >
                        <table className="cafeOwner_offer" border="1">
                            <thead>
                                <th>Cafe id</th>
                                <th>offer Name</th>
                                <th>Offer Description</th>
                                <th>update</th> <th>Delete</th>
                            </thead>
                            {this.state.kalu.map((ag, key) => (
                                <tr key={key + ag.Offer_name}>
                                    <td>{ag.Cafe_id}</td>
                                    <td>{ag.Offer_name}</td>
                                    <td>{ag.Offer_description}</td>
                                    <td>
                                        <button
                                            type="submit"
                                            onClick={() => this.update(ag.Cafe_id, ag.Offer_name)}
                                        >
                                            Update
                                        </button>
                                    </td>
                                    <td>
                                        <button
                                            type="submit"
                                            onClick={() => this.Del(ag.Cafe_id, ag.Offer_name)}
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </table> <br/>
                        <div className = "btn">
                            <button  type="submit" onClick={this.Insert}>
                                Insert
                            </button>
                        </div>
                    </div>
                    </div>
                )}
            </div>
        );
    }
}

export default Display;
