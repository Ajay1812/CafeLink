import React, { Component } from 'react';
import Math from './Math';
import './Cafeowner.css'

class Cafeowner extends Component {

    constructor()
    {
        super();
        this.state={
            
            
    };
}

    render(){

    
    return (  <div>
        <img src = "Icon/CafeLink.png" alt = "image" width="102"></img>
        <img src = "Icon/Cafeowner.png" alt = "image" width="60" className = "Cafe2"></img>
        <label className = "Cafe3"><b>IN & OUT</b></label>
        <img src = "Icon/bellicon.jpg" alt = "image" width="60" className = "Cafe4"></img>
        <label className = "Cafe1"><b>CafeLink</b></label>
        <hr/>
        <div>
            <img src = "Icon/restaurantmenu.png" alt = "image" width="120"className = "Cafe5" ></img>
            <img src = "Icon/AddEvent.jpg" alt = "image" width="125"className = "Cafe6" ></img>
            <div>
            <a href = "#" className = "Menu3">Menu</a>
            <a href ="#" className = "Menu4">Add</a>
            </div>
            <div>
            <a href ="#" className = "Event4">Update</a> 
            <a href = "#" className = "Event3">Event</a>
            
            </div>
        </div>
        <div>
            <img src = "Icon/discount.png" alt = "image" width="120"className = "Cafe5" ></img>
            <img src = "Icon/Review.png" alt = "image" width="130"className = "Cafe6" ></img>
            <div>
            {/* <a href = "#" className = "Event2">Read</a> <br/>
            <a href = "#" className = "Menu2">Reviews</a> */}
            <button type = "submit" >Read <br/> Reviews</button>
            </div>
            <div>
            <a href ="#" className = "Event1">Add</a> <br/>
            <a href ="#" className = "Menu1">Offers</a>
            </div>
            
        </div>


    </div>
        
        
    );
}
}

export default Cafeowner;
