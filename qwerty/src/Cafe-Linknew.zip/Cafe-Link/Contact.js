import React, { Component } from 'react';
// import Math from './Math';
import './Contact.css'
class Contact extends Component {

    constructor()
    {
        super();
        this.state={
            
            
    };
}

    render(){

    
    return ( <div className = "Contact" >
        <h2 className=""> Contact Us</h2> <br/>
        <div className="label">
        <label>Email : CafeLink657@gmail.com</label> <br/>
        <label>Phone No. : 6397XXXXXX</label>
        </div>
        <div className = "Social"><b>Social Media</b></div> <br/>
        <div><table className = "Share"><td>
            <img  src = "Icon/facebook.png" alt = "image" width="40" className = "face"></img>
            <img  src = "Icon/instagram.png" alt = "image" width="40"className = "insta"></img>
            <img  src = "Icon/pinterest.png" alt = "image" width="40"className = "pint"></img>
        </td>
            </table></div>
        <table className = "logo">
            <td><img src = "Icon/CafeLink.png" alt = "image" width="80"></img></td>
            <td className = "copy">Copyright © 2020-2021 CafeLink Company S.L. All rights reserved.</td>
        </table>
        
        
        
        
        
    </div>
        
    );
}
}

export default Contact;
