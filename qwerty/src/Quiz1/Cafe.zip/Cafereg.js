import React, { Component } from 'react';
import './Cafereg.css'
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import TextField from '@material-ui/core/TextField';

class Cafereg extends Component {

    constructor() {
        super();
        this.state = {
            
            


        };
    }

    render() {
    return (<div className="body">
            <h2 className="cafe_head"><b>Cafe Registraion</b></h2>
            {/* <input type="text" className = "id" placeholder ="Cafe id"></input> <br/> <br/> */}
            <Box textAlign='center'>
            <TextField id="outlined-basic" label ="Cafe id" variant="outlined"/></Box><br/> <br/>
            {/* <input type="text" className = "id" placeholder ="Cafe Name"></input><br/><br/> */}
            <Box textAlign='center'>
            <TextField id="outlined-basic" label ="Cafe Loaction" variant="outlined"/></Box><br/><br/>
            {/* <input type="text" className = "id" placeholder ="Cafe Loaction"></input><br/><br/> */}
            <Box textAlign='center'>
            <TextField id="outlined-basic" label ="Cafe Email"  variant="outlined"/></Box><br/><br/>

            {/* <input type="Email" className = "id" ></input><br/><br/> */}
            <Box textAlign='center'>
            <TextField id="outlined-basic" label ="Cafe Password"variant="outlined" /></Box><br/><br/><br/>
            {/* <input type="Password" className = "id" placeholder ="Cafe Password"></input><br/> <br/> <br/> */}
            <Box textAlign='center'>
            <Button  className="Button1" variant="contained" color="primary" size="large" placeholder ="Cafe Password" >
                    Register</Button></Box><br />
        </div>

        );
    }
}

export default Cafereg;



