import { render } from '@testing-library/react'
import React, { Component } from 'react'

class Math extends Component{

render() {

    return (
        <div>

            <p>Qus 1. In a century how many months are there?</p>
            <input id = "Q1." type = "radio" name = "5"></input>
            <label for="Q1.">12</label><br/>
            <input id = "Q1." type = "radio" name = "5"></input> 
            <label for="Q1.">120</label><br/>
            <input id = "Q1." type = "radio" name = "5"></input> 
            <label for="Q1.">1200</label><br/>
            <input id = "Q1." type = "radio" name = "5"></input>
            <label for="Q1.">12000</label><br/>
            
            <p>Qus 2.What is the value of x if x<sup>2</sup> = 169</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">1</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">13</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">169</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">338</label><br/>
            
            <p>Qus 3. What is the square of 15?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">15</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">30</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">225</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">252</label><br/>

            <p>Qus 4.  Area of a parallelogram whose base is 9 cm and height is 4 cm is ……….. square cm.</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">9</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">4</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">36</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">13</label><br/>

            <p>Qus 5.  10<sup>-2</sup> means …………. </p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">10</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">11</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">12</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">14</label><br/>

            <p>Qus 6.  The cube root of 1331 is ………… .</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">11</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">13</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">19</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">17</label><br/>

            <p>Qus 7.  10003 – 999 = ………….. .</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2."> 4009</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">9004</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">9040</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">9047</label><br/>

            <p>Qus 8.   The square root of 0.0081 is ………… .</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">0.09</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">0.91</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">0.009</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">0.9</label><br/>

            <p>Qus 9.  What is the angle the hour hand of a clock makes with the minute hand when the time is 15.40?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">110</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">120</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">125</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">130 and 75</label><br/>
            
            <p>Qus 10.  A clock seen through a mirror shows 8 o’clock. What is the correct time?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">8.00</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2."> 4.00</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">12.00</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">12.40</label><br/> 
        </div>
    );
    }
    
}


export default Math;
