import React from 'react'
import "./Sports.css"

function Sports() {
    fetch ('https://quizapi.io/api/v1/questions?apiKey=YOUR_API_KEY&category=Math&difficulty=Easy&limit=10 ')


    return (
        <div>

            <p>Qus 1. Who was the first Prime Minister of India?</p>
            <input id = "Q1." type = "radio" name = "5"></input>
            <label for="Q1.">Indira Gandhi</label><br/>
            <input id = "Q1." type = "radio" name = "5"></input> 
            <label for="Q1.">Narendra Modi</label><br/>
            <input id = "Q1." type = "radio" name = "5"></input> 
            <label for="Q1.">Jawaharlal Nehru</label><br/>
            <input id = "Q1." type = "radio" name = "5"></input>
            <label for="Q1.">Jawaharlal Nehru</label><br/>
            
            <p>Qus 2.What is the capital city of India?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">New Delhi</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Mumbai</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Kolkata</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Chennai</label><br/>
            
            <p>Qus 3. Which state is also known as the “Fruit Bowl” of India?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Jammu and Kashmir</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Himachal Pradesh</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Assam</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Meghalaya</label><br/>

            <p>Qus 4.  Who is Sachin Tendulkar?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Indian Hockey player</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Indian Cricketer</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Indian Kabaddi player</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Indian Marathon Runner</label><br/>

            <p>Qus 5.  Who discovered India?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Vasco da Gama</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Christopher Columbus</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">James Cook</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Willem Janszoon</label><br/>

            <p>Qus 6.  Which is the national sport of India?.</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Cricket</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Hockey</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Kabaddi</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Football</label><br/>

            <p>Qus 7.  Who is popularly known as the “Iron Man” of India?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2."> Lal Bahadur Shastri</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Sardar Vallabh Bhai Patel</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Mahatma Gandhi</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Dr. B.R Ambedkar</label><br/>

            <p>Qus 8.   Where is Taj Mahal located in India?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">New Delhi</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Kolkata</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Agra</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Lucknow</label><br/>

            <p>Qus 9.  Who is the current President of India?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Ram Nath Kovind</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Pranab Mukherjee</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">A. P. J. Abdul Kalam</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Pratibha Patil</label><br/>
            
            <p>Qus 10.  What is the capital of Maharashtra?</p>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">Mumbai</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2."> New Delhi</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input> 
            <label for="Q2.">Chennai</label><br/>
            <input id = "Q2." type = "radio" name = "5"></input>
            <label for="Q2.">None of the above</label><br/> 
        </div>
    )
}

export default Sports