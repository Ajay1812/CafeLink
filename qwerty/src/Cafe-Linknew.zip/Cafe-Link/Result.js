import React, { Component } from 'react';
import Rslt from './Rslt.css';

import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
// import Box from '@material-ui/core/Box';
import Container from '@material-ui/core/Container';
// import wner from './wner.jpg';

class Result extends Component {
    render() {
        return (<div>
            <Container fixed>

                {/* <div ClassName="n2"> */}
                <div className="v1">
                    <h1>WINNERS</h1>



                    <br></br>
                    <br></br>

                    <TextField id="standard-basic" label="1st place" />
                    <br></br>
                    <br></br>
                    <TextField id="standard-basic" label="2nd place" />
                    <br></br>
                    <br></br>
                    <TextField id="standard-basic" label="3rd place" />
                    <br></br>
                    <br></br>
                </div>
                {/* </div> */}
            </Container>







        </div>);
    }



}
export default Result;
