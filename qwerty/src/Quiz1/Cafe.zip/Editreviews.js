import React, { Component } from 'react';
import './Editreviews.css'
import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
class Editreviews extends Component {

    constructor() {
        super();
        this.state = {
            
            


        };
    }

    render() {
    return (<div>
            <h2><b>Edit Reviews</b></h2>
            {/* <input type="text" className = "id1" placeholder ="Cafe id"></input> <br/> <br/> */}
            <Box textAlign='center'>
            <TextField id="outlined-basic" label="Cafe_id" variant="outlined" /></Box><br/> 
            {/* <input type="text" className = "id1" placeholder ="Customer id"></input> <br/> <br/> */}
            <Box textAlign='center'>
            <TextField id="outlined-basic" label="Custome_id" variant="outlined" /></Box><br/> 
            {/* <input type="text" className = "id2" placeholder ="Review Text"></input> <br/> <br/> */}
            <Box textAlign='center'>
            <TextField id="outlined-basic" label="Review Text" variant="outlined" /></Box><br/> <br/>
            {/* <button className = "button">Update</button> */}
            <Box textAlign='center'>
            <Button  className="Button2" variant="contained" color="primary" size="large" >
                    Update</Button></Box>

        </div>

        );
    }
}

export default Editreviews;



